<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="Explore accommodations for your next travel adventure"/>
    <meta name="author" content="Your Name"/>
    <title>Accommodations</title>
  
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <link href="css/font-awesome.min.css" rel="stylesheet"/>
    <link href="css/animate.min.css" rel="stylesheet"/>
    <link href="css/main.css" rel="stylesheet"/> 
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa; /* Light gray background */
            font-family: Arial, sans-serif; /* Use Arial font */
            color: #333; /* Dark gray text color */
            padding: 0; /* Remove default padding */
            margin: 0; /* Remove default margin */
        }
        #header {
            background-color: #007bff; /* Blue header background */
            padding: 10px; /* Add some padding */
            color: #fff; /* White text color */
        }
        #accommodations {
            background-color: #fff; /* White section background */
            padding: 20px; /* Add some padding */
            margin-top: 20px; /* Add margin to separate from header */
            border-radius: 10px; /* Add rounded corners */
            box-shadow: 0 0 10px rgba(0,0,0,0.1); /* Add shadow effect */
        }
        .accommodation {
            margin-bottom: 20px; /* Add some bottom margin */
        }
        .accommodation h3 {
            font-size: 24px; /* Larger font size for title */
            color: #007bff; /* Blue title color */
        }
        .accommodation p {
            font-size: 18px; /* Font size for description */
        }
        #footer {
            background-color: #333; /* Dark gray footer background */
            padding: 20px; /* Add some padding */
            color: #fff; /* White text color */
            text-align: center; /* Center-align text */
            margin-top: 20px; /* Add margin to separate from content */
            border-radius: 10px; /* Add rounded corners */
        }
    </style>
</head>

<body> 
    <!-- Navigation Section -->
    <section id="header">
        <div class="container">
            <div class="row">  
                <div class="col-md-12" style="text-align: center;"> 
                    <a href="home.php" style="font-size: 18px; color: #fff;">Home</a> 
                </div>
            </div>
        </div>
    </section>
    
    <!-- Accommodations Section -->
    <section id="accommodations">
        <div class="container">
            <div class="accommodation">
                <h3>Cox's Bazar Villa</h3>
                <p>Enjoy your stay in our luxurious beachfront villa with stunning ocean views. Each room is equipped with two fans and three lights for ample lighting and comfort.</p>
            </div>
            
            <div class="accommodation">
                <h3>Mountain Keokradong</h3>
                <p>Experience tranquility in our cozy mountain cabin nestled amidst scenic nature trails. Our cabin features a fireplace, perfect for warming up after a day of exploration.</p>
            </div>
            
            <div class="accommodation">
                <h3>Sundarbans</h3>
                <p>Immerse yourself in urban living with our stylish traveling sites with loft located in the heart of downtown. This modern loft offers sleek raw and convenient access to nature.</p>
            </div>
        </div>
    </section>

    <!----- Footer ----->
    <section id="footer"> 
        <div class="container">
        Travel with us because we care about you and your beloved ones
        </div>
    </section>
  
    <!-- JavaScript Libraries -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/wow.min.js"></script>
</body> 
</html>
