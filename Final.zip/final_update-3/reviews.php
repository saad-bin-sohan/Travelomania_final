<?php
// Database connection details
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "370_project"; // Adjust to your database name

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If the form is submitted, process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize form input
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $review_text = mysqli_real_escape_string($conn, $_POST['review_text']);
    $rating = (int)$_POST['rating']; // Cast to integer

    // Prepare SQL query to insert review into "reviews" table
    $stmt = $conn->prepare("INSERT INTO reviews (username, review_text, rating) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $username, $review_text, $rating);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo "Review submitted successfully!";
    } else {
        echo "Error submitting review: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Review</title>
    <style>
        /* Styling for the form and layout */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light gray background */
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #333;
            text-align: center;
        }
        label {
            font-weight: bold;
            color: #555;
        }
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff; /* Blue button */
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Submit a Review</h2>
        <form action="" method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" required><br>
            
            <label for="review_text">Review Text:</label>
            <textarea name="review_text" required></textarea><br>
            
            <label for="rating">Rating (1-5):</label>
            <input type="number" name="rating" min="1" max="5" required><br>
            
            <input type="submit" value="Submit Review">
        </form>
    </div>
</body>
</html>