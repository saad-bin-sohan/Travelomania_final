<?php
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "370_project";


$conn = new mysqli($servername, $db_username, $db_password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $employee_guide = mysqli_real_escape_string($conn, $_POST['employee_guide']);

    
    $sql = "insert into travel_guide (username,employee_id) values('$username','$employee_guide')";
    echo $sql;

    if ($conn->query($sql) === TRUE) {
        
        header("Location: done.html");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }

   
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Assistance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1, h2 {
            color: #007bff;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Let Us Ease Your Travel With An Assistance</h1>

        <h2>Book a Personal Travel Guide</h2>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter username" required><br>
            
            <label for="employee_guide">Select Guide (1/2/3):</label>
            <input type="text" id="employee_guide" name="employee_guide" placeholder="Enter Guide Number" required><br>
            
            <input type="submit" value="Book Guide">
        </form>

    </div>
</body>
</html>
