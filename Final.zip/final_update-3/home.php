<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('bgd.png'); /* Background image */
            background-size: cover;
            background-repeat: no-repeat;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #007bff; /* Blue heading color */
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            background-color: #007bff; /* Blue button background */
            color: #fff; /* White button text color */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
        .button img {
            max-width: 100px;
            height: auto;
            margin-bottom: 10px;
        }
        p {
            font-size: 18px;
            margin-top: 20px;
            color: #333; /* Dark gray text color */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Travellomania</h1>
        <div class="button" onclick="navigateTo('sign_in.php')">
            <img src="sign_in_icon.png" alt="Sign In Icon">
            <div>Sign In</div>
        </div>
        <div class="button" onclick="navigateTo('sign_up.php')">
            <img src="sign_up_icon.png" alt="Sign Up Icon">
            <div>Sign Up</div>
        </div>
        <div class="button" onclick="navigateTo('look_for_accommodations.php')">
            <img src="accommodation_icon.png" alt="Accommodation Icon">
            <div>Look for places you can visit</div>
        </div>
        <div class="button" onclick="navigateTo('travel_assistance.php')">
            <img src="travel_guide_icon.png" alt="Travel Guide Icon">
            <div>Book a Travel Guide</div>
        </div>
        <p>Travel With Us Because We Care About Your Loved Ones</p>
    </div>

    <script>
        function navigateTo(url) {
            window.location.href = url;
        }
    </script>
</body>
</html>
