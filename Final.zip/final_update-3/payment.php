<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>Payment Page</h1>
    <form id="paymentForm" method="post" action="process_payment.php">
        <label for="paymentType">Payment Type (c for card_banking, m for mobile_banking):</label>
        <input type="text" id="paymentType" name="paymentType" required><br><br>
        
        <label for="transactionId">Transaction ID:</label>
        <input type="text" id="transactionId" name="transactionId" required><br><br>
        
        <input type="submit" value="Submit">
    </form>

    <script>
        // Add your JavaScript here
    </script>
</body>
</html>
<?php
// Include your database connection file here
// Assuming your connection file is named 'db_connection.php'
include 'dbconnect.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $paymentType = $_POST['paymentType'];
    $transactionId = $_POST['transactionId'];

    // Validate payment type (c or m)
    if ($paymentType === 'c') {
        // For card_banking, store transaction id with null account_no
        $query = "INSERT INTO card_banking (transaction_id, account_no) VALUES ('$transactionId', NULL)";
    } elseif ($paymentType === 'm') {
        // For mobile_banking, store transaction id with null reference
        $query = "INSERT INTO mobile_banking (transaction_id, reference) VALUES ('$transactionId', NULL)";
    } else {
        // Invalid payment type, handle error (optional)
        echo "Invalid payment type.";
        exit();
    }

    // Execute query
    if (mysqli_query($conn, $query)) {
        echo "Payment information stored successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    // Close database connection
    mysqli_close($conn);
}
?>
