<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="Explore accommodations for your next travel adventure"/>
    <meta name="author" content="Your Name"/>
    <title>Booking</title>
  
    <!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <link href="css/font-awesome.min.css" rel="stylesheet"/>
    <link href="css/animate.min.css" rel="stylesheet"/>
    <link href="css/main.css" rel="stylesheet"/> 
</head>

<body> 
    <!-- Navigation Section -->
    <section id="header" style="background-color: #007bff; padding: 10px;">
        <div class="container">
            <div class="row">  
                <div class="col-md-12" style="text-align: center;"> 
                    <a href="home.php" style="font-size: 18px; color: #fff;">Home</a> 
                </div>
            </div>
        </div>
    </section>
    
    <!-- Booking Section -->
    <section id="booking" style="background-color: #f8f9fa; padding: 20px;">
        <div class="container">
            <h1 style="color: #343a40;">Booking</h1>
            <button onclick="bookFlights()" style="background-color: #28a745; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; margin-right: 10px;">Book Flights</button>
            <button onclick="cancelFlights()" style="background-color: #dc3545; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; margin-right: 10px;">Cancel Flights</button>
            <h2 style="color: #343a40;">Search for Accommodations:</h2>
            <button onclick="searchAccommodations()" style="background-color: #007bff; color: #fff; padding: 10px 20px; border: none; border-radius: 5px;">Search Accommodations</button>
            <h2>Reviews:</h2>
            <button onclick="viewReviews()" style="background-color: #007bff; color: #fff; padding: 10px 20px; border: none; border-radius: 5px;">Go to Reviews</button>
        </div>
    </section>

    <!-- JavaScript Libraries -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
        function bookFlights() {
            // Redirect to the booking flights page
            window.location.href = "book_flights.php";
        }

        function cancelFlights() {
            // Redirect to the cancel flights page
            window.location.href = "cancel_flights.php";
        }

        function searchAccommodations() {
            // Redirect to the accommodations page where users can choose from available options
            window.location.href = "look_for_accommodations.php";
        }

        function viewReviews() {
            // Redirect to the reviews page
            window.location.href = "reviews.php";
        }
    </script>
</body> 
</html>
