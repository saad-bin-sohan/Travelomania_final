-- Active: 1712324783501@@127.0.0.1@3306@370_project
CREATE DATABASE `370_project`;

USE `370_project`;

CREATE TABLE transportation (
    vehicle_id INT PRIMARY KEY,
    availability BOOLEAN
);

CREATE TABLE payment (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    amount DECIMAL(10, 2) NOT NULL,
    dd_mm_yy DATE
);

CREATE TABLE users (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    vehicle_id INT,
    trx_id INT,
    FOREIGN KEY (vehicle_id) REFERENCES transportation(vehicle_id),
    FOREIGN KEY (trx_id) REFERENCES payment(transaction_id)
);

CREATE TABLE travel_guide (
    employee_id INT PRIMARY KEY,
    username VARCHAR(50), 
    FOREIGN KEY (username) REFERENCES users(username)
);


CREATE TABLE user_email (
    username VARCHAR(50),
    email VARCHAR(100),
    FOREIGN KEY (username) REFERENCES users(username)
);


CREATE TABLE destination (
    location_id INT PRIMARY KEY,
    attractions TEXT,
    username VARCHAR(50),
    FOREIGN KEY (username) REFERENCES users(username)
);

CREATE TABLE card_banking (
    transaction_id INT,
    account_no VARCHAR(20),
    PRIMARY KEY (transaction_id, account_no),
    FOREIGN KEY (transaction_id) REFERENCES payment(transaction_id)
);


CREATE TABLE mobile_banking (
    transaction_id INT PRIMARY KEY,
    reference VARCHAR(50),
    FOREIGN KEY (transaction_id) REFERENCES payment(transaction_id)
);


CREATE TABLE customer_support (
    username VARCHAR(50),
    faq VARCHAR(255),
    PRIMARY KEY (username, faq),
    FOREIGN KEY (username) REFERENCES users(username)
);


CREATE TABLE user_support (
    username VARCHAR(50),
    faq VARCHAR(255),
    PRIMARY KEY (username, faq),
    FOREIGN KEY (username) REFERENCES users(username)
);


CREATE TABLE booked_flights (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    flight_from varchar(50),
    flight_to varchar(50),
    departure_date date,
    return_date date,
    location_id INT,
    FOREIGN KEY (username) REFERENCES users(username),
    FOREIGN KEY (location_id) REFERENCES destination(location_id)
);

CREATE TABLE reviews (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    review_text TEXT,
    rating INT,
    FOREIGN KEY (username) REFERENCES users(username)
);