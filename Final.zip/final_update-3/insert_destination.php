<!DOCTYPE html>
<html>

<head>
    <title>Insert Page page</title>
</head>

<body>
    <center>
        <?php
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "370_project"; // Corrected database name

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Check connection
            if($conn === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

            // Taking all values from the form data(input)
            $username_0 = mysqli_real_escape_string($conn, $_POST['dname']); // Escape user inputs for security
            $password_0 = mysqli_real_escape_string($conn, $_POST['pass']); // Escape user inputs for security
            //die($username_0);
            // Performing insert query execution
            $sql = "INSERT INTO users (username, password) VALUES ('$username_0', '$password_0')";

            if(mysqli_query($conn, $sql)){
                echo "<h3>Data stored in the database successfully."
                    . " Please browse your localhost php my admin"
                    . " to view the updated data</h3>"; 

            } else{
                echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
            }

            // Close connection
            mysqli_close($conn);
        } else {
            echo "<h3>Error: Form not submitted. Please submit the form.</h3>";
        }
        ?>
    </center>
</body>

</html>
