<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Support</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light gray background */
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff; /* White background */
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #007bff; /* Blue heading color */
        }
        .question {
            font-weight: bold;
            color: #007bff; /* Blue question color */
            margin-bottom: 5px;
        }
        .answer {
            margin-bottom: 20px;
            color: #333; /* Dark gray answer color */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Customer Support</h2>
        
        <div class="question">Q: How do I create an account?</div>
        <div class="answer">A: To create an account, click on the "Sign Up" button on the homepage and fill out the registration form.</div>
        
        <div class="question">Q: Can I cancel my booking?</div>
        <div class="answer">A: Yes, you can cancel your booking by visiting the "Booking" page and selecting the option to cancel.</div>
        
        <div class="question">Q: How do I contact customer support?</div>
        <div class="answer">A: You can contact customer support by sending an email to <span style="color: #007bff;">support@example.com</span> or by calling our helpline at <span style="color: #007bff;">+123456789</span>.</div>
        
        <div class="question">Q: What payment methods are accepted?</div>
        <div class="answer">A: We accept payments via credit/debit card, bank transfer, and mobile banking.</div>
    </div>
</body>
</html>
