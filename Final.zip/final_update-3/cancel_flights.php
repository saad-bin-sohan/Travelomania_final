<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancel Flights</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light gray background */
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #007bff; /* Blue heading color */
        }
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff; /* White form background */
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
            color: #333; /* Dark gray label color */
        }
        input[type="text"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff; /* Blue button background */
            color: #fff; /* White button text color */
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>
<body>
    <h1>Cancel Flights</h1>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <label for="booking_id">Booking ID:</label><br>
        <input type="text" id="booking_id" name="booking_id"><br>
        
        <input type="submit" name= "cancel" value="Cancel">
    </form>

<?php
    // Include database connection file
    include_once "dbconnect.php";

    // Check if booking form is submitted
    if (isset($_POST['cancel'])) {
        // Sanitize user input to prevent SQL injection (optional but recommended)
        $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']); // New username field
        
        

        // Prepare SQL query to insert booking details
        $sql = "DELETE FROM booked_flights WHERE booking_id = '$booking_id' ";

        // Execute the query and check for errors
        if (mysqli_query($conn, $sql)) {
            echo "<p>Cancellation successful!</p>";
            echo '<a href="done.html">Go to Done</a>'; // Link to done.html
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
    ?>
</body>
</html>
