<?php
// Database connect kortesi
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "370_project";

//connection create kortesi
$conn = new mysqli($servername, $username, $password, $dbname);

//connection check kortesi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check kortesi if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check kortesi if user exists and password is correct
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($password == $row["password"]) {
            echo "<p style='color: green;'>Login successful!</p>";
            // Redirect to booking.php
            header("Location: booking.php");
            exit();
        } else {
            echo "<p style='color: red;'>Invalid password!</p>";
        }
    } else {
        echo "<p style='color: red;'>User not found!</p>";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #007bff; 
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input[type="text"], input[type="password"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff; 
            color: #fff; 
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3; 
        }
        .support-btn {
            background-color: #28a745; 
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }
        .support-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <h2>Sign In</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="username">Username:</label><br>
        <input type="text" name="username" id="username" required><br><br>
        <label for="password">Password:</label><br>
        <input type="password" name="password" required><br><br>
        <input type="submit" value="Sign In">
    </form>

    <a href="customer_support.php" class="support-btn">Customer Support</a> 
</body>
</html>
