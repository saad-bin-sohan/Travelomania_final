<?php
// Start session to access session variables
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header("Location: look_for_accommodations.php");
    exit(); // Stop script execution
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required form fields are filled
    if (isset($_POST['flight_id']) && isset($_POST['date']) && isset($_POST['passenger_count'])) {
        // Retrieve form data
        $flight_id = $_POST['flight_id'];
        $date = $_POST['date'];
        $passenger_count = $_POST['passenger_count'];

        // Validate form data (you can add more validation if needed)

        // Perform booking process (you can add your booking logic here)
        // Example: Insert booking information into database

        // Provide feedback to the user
        echo "<h3>Booking Successful!</h3>";
        echo "<p>You have successfully booked $passenger_count seat(s) for flight $flight_id on $date.</p>";
        echo "<p>Thank you for choosing our service!</p>";
    } else {
        // If any required form field is missing, show an error message
        echo "<h3>Error: All fields are required.</h3>";
    }
} else {
    // If the form is not submitted, redirect to the booking page
    header("Location: book_flights.php");
    exit(); // Stop script execution
}
?>
