<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Flights</title>
    <style>
        body {
            background-color: #f8f9fa; /* Light gray background */
            font-family: Arial, sans-serif; /* Use Arial font */
            color: #333; /* Dark gray text color */
            padding: 20px; /* Add some padding */
        }

        h1 {
            color: #007bff; /* Blue heading color */
        }

        form {
            background-color: #fff; /* White form background */
            padding: 20px; /* Add some padding */
            border-radius: 10px; /* Add rounded corners */
            box-shadow: 0 0 10px rgba(0,0,0,0.1); /* Add shadow effect */
        }

        label {
            color: #007bff; /* Blue label color */
        }

        input[type="text"],
        input[type="date"],
        input[type="submit"] {
            width: 100%; /* Full width input fields */
            padding: 10px; /* Add some padding */
            margin-bottom: 10px; /* Add some margin */
            border: 1px solid #ccc; /* Add a border */
            border-radius: 5px; /* Add rounded corners */
        }

        input[type="submit"] {
            background-color: #007bff; /* Blue button background */
            color: #fff; /* White text color */
            cursor: pointer; /* Add cursor on hover */
        }

        input[type="submit"]:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        a {
            color: #007bff; /* Blue link color */
            text-decoration: none; /* Remove underline */
        }

        a:hover {
            text-decoration: underline; /* Add underline on hover */
        }
    </style>
</head>
<body>
    <h1>Book Flights</h1>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username"><br>
        
        <label for="flight_from">From:</label><br>
        <input type="text" id="flight_from" name="flight_from"><br>
        
        <label for="flight_to">To:</label><br>
        <input type="text" id="flight_to" name="flight_to"><br>
        
        <label for="departure_date">Departure Date:</label><br>
        <input type="date" id="departure_date" name="departure_date"><br>
        
        <label for="return_date">Return Date:</label><br>
        <input type="date" id="return_date" name="return_date"><br>
        
        <input type="submit" name="submit_booking" value="Book">
    </form>

    <?php
    // Include database connection file
    include_once "dbconnect.php";

    // Check if booking form is submitted
    if (isset($_POST['submit_booking'])) {
        // Sanitize user input to prevent SQL injection (optional but recommended)
        $username = mysqli_real_escape_string($conn, $_POST['username']); // New username field
        $flight_from = mysqli_real_escape_string($conn, $_POST['flight_from']);
        $flight_to = mysqli_real_escape_string($conn, $_POST['flight_to']);
        $departure_date = mysqli_real_escape_string($conn, $_POST['departure_date']);
        $return_date = mysqli_real_escape_string($conn, $_POST['return_date']);
        

        // Prepare SQL query to insert booking details
        $sql = "";
        $sql2 = ''; 
        if ($flight_to == "Coxs Bazar Villa" ) {
            $sql ="INSERT INTO booked_flights (username, flight_from, flight_to, departure_date, return_date, location_id) VALUES ('$username', '$flight_from', '$flight_to', '$departure_date', '$return_date', 1)";
            $sql2 = "INSERT IGNORE INTO destination (location_id, attractions, username) VALUES
            (1, 'Cox\'s Bazar Villa', '$username')"; 
           
        } elseif ($flight_to == 'Mountain Keokradong' ) {
            $sql ="INSERT INTO booked_flights (username, flight_from, flight_to, departure_date, return_date, location_id) VALUES ('$username', '$flight_from', '$flight_to', '$departure_date', '$return_date', 2)";
            $sql2 = "INSERT IGNORE INTO destination (location_id, attractions, username) VALUES
          
           (2, 'Mountain Keokradong', '$username');";
           
        } elseif ($flight_to == 'Sundarbans' ){
            $sql ="INSERT INTO booked_flights (username, flight_from, flight_to, departure_date, return_date, location_id) VALUES ('$username', '$flight_from', '$flight_to', '$departure_date', '$return_date', 3)";
            $sql2 = "INSERT IGNORE INTO destination (location_id, attractions, username) VALUES
           (3, 'Sundarbans', '$username');";

        }
        

        // Execute the query and check for errors

        if (mysqli_query($conn, $sql2)) {
            echo "<p>Destination is loaded!</p>";
           
        } else {
            echo "Error: " . mysqli_error($conn);
        }
        $booking_id = mysqli_insert_id($conn); // Retrieve the last inserted booking ID
        echo "<p>Booking successful! Your booking ID is: $booking_id</p>";
        if (mysqli_query($conn, $sql)) {
            echo "<p>Booking successful!</p>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
       
    }
    ?>
</body>
</html>
