<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "370_project";

// Creating connection
$conn = new mysqli($servername, $username, $password);

// Check connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    // Selecting the travel database
    mysqli_select_db($conn, $dbname);
    //echo "Connection successful";
}

?>
